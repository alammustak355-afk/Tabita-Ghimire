package com.connectai.crm.model

enum class NavDestination(val route: String, val label: String, val group: String) {
    OVERVIEW("overview", "Overview", "Primary"),
    LEAD_CENTER("leads", "Lead Center", "Primary"),
    UNIFIED_INBOX("inbox", "Unified Inbox", "Primary"),
    AI_COPILOT("copilot", "AI Copilot", "Primary"),
    WHATSAPP_CHANNELS("channels", "WhatsApp & Channels", "Primary"),
    CAMPAIGN_STUDIO("campaigns", "Campaign Studio", "Growth"),
    RECRUITMENT_PIPELINE("pipeline", "Recruitment Pipeline", "Recruitment"),
    FOLLOW_UP_TASKS("tasks", "Follow-up Tasks", "Recruitment"),
    TEAM_PERFORMANCE("team", "Team & Performance", "Governance"),
    ANALYTICS_REPORTS("analytics", "Analytics & Reports", "Governance"),
    INTEGRATIONS("integrations", "Integrations", "Governance"),
    SETTINGS_SECURITY("settings", "Settings & Security", "Governance")
}

val RECRUITMENT_STAGES = listOf(
    "New Lead",
    "Contacted",
    "Interested",
    "Documents Pending",
    "Qualified",
    "Employer Review",
    "Offer",
    "Visa Process",
    "Deployed",
    "Rejected",
    "On Hold"
)

data class TenantWorkspace(
    val id: Int,
    val name: String,
    val slug: String,
    val industry: String,
    val timezone: String,
    val plan: String,
    val emergencyPause: Boolean,
    val aiDisclosureEnabled: Boolean,
    val retentionDays: Int
)

data class UserProfile(
    val id: Int,
    val uid: String,
    val email: String,
    val name: String,
    val role: String
)

data class ContactRecord(
    val id: Int,
    val name: String,
    val phone: String,
    val email: String,
    val company: String,
    val sourceChannel: String,
    val consentStatus: String,
    val assignedEmployee: String,
    val requirementsSummary: String,
    val notes: String
)

data class LeadCandidateRecord(
    val id: Int,
    val title: String,
    val contactName: String,
    val phone: String,
    val email: String,
    val nationality: String,
    val preferredJob: String,
    val destinationCountry: String,
    val ownerName: String,
    val sourceChannel: String,
    val priority: String,
    val stage: String,
    val leadScore: Int,
    val extractedRequirements: String,
    val notes: String,
    val estimatedValueUsd: Double,
    val nextAction: String,
    val dueDate: String,
    val isArchived: Boolean = false
)

data class ConversationRecord(
    val id: Int,
    val customerName: String,
    val customerHandleOrPhone: String,
    val channelType: String,
    val status: String,
    val priority: String,
    val assignedEmployee: String,
    val handlingMode: String,
    val unreadCount: Int,
    val lastMessagePreview: String,
    val aiSummary: String,
    val suggestedReply: String
)

data class MessageRecord(
    val id: Int,
    val conversationId: Int,
    val senderType: String,
    val senderName: String,
    val direction: String,
    val content: String,
    val deliveryStatus: String
)

data class WhatsAppChannelRecord(
    val id: Int,
    val phoneNumber: String,
    val displayName: String,
    val phoneNumberId: String,
    val channelType: String,
    val department: String,
    val assignedStaffName: String,
    val aiStatus: String,
    val connectionStatus: String,
    val recentError: String?
)

data class SocialBoostCampaignRecord(
    val id: Int,
    val channelType: String,
    val campaignName: String,
    val objective: String,
    val adCopy: String,
    val dailyBudgetUsd: String,
    val durationDays: Int,
    val status: String,
    val impressions: Int,
    val clicks: Int,
    val conversationsStarted: Int,
    val qualifiedLeadsCount: Int
)

data class TaskItemRecord(
    val id: Int,
    val title: String,
    val taskType: String,
    val assignedEmployee: String,
    val contactName: String,
    val dueDate: String,
    val priority: String,
    val status: String
)

data class AppointmentItemRecord(
    val id: Int,
    val contactName: String,
    val title: String,
    val scheduledAt: String,
    val durationMinutes: Int,
    val status: String,
    val channelSource: String
)

data class AiAgentRecord(
    val id: Int,
    val name: String,
    val department: String,
    val assignedChannels: String,
    val communicationStyle: String,
    val confidenceThreshold: Int,
    val responseMode: String,
    val isActive: Boolean
)

data class IntegrationRecord(
    val id: Int,
    val providerKey: String,
    val displayName: String,
    val category: String,
    val status: String,
    val maskedCredentialHint: String,
    val requiredPermissions: String,
    val setupInstructions: String
)

data class InvitationRecord(
    val id: Int,
    val email: String,
    val role: String,
    val department: String,
    val status: String,
    val invitedBy: String
)

data class AuditLogRecord(
    val id: Int,
    val actorName: String,
    val action: String,
    val resourceType: String,
    val details: String
)

data class AiCopilotResult(
    val headline: String,
    val summary: String,
    val draftText: String,
    val bulletPoints: List<String>,
    val recommendedAction: String,
    val requiresHumanApproval: Boolean
)

data class ApiDiagnosticInfo(
    val endpointUrl: String = "",
    val httpStatusCode: Int = 0,
    val contentType: String = "",
    val errorSummary: String = "",
    val remediationHint: String = ""
)

data class CrmWorkspaceSnapshot(
    val isLiveBackend: Boolean,
    val connectionBanner: String,
    val apiDiagnostic: ApiDiagnosticInfo = ApiDiagnosticInfo(),
    val user: UserProfile,
    val activeTenant: TenantWorkspace,
    val authorizedTenants: List<TenantWorkspace>,
    val contacts: List<ContactRecord>,
    val leads: List<LeadCandidateRecord>,
    val conversations: List<ConversationRecord>,
    val messages: List<MessageRecord>,
    val channels: List<WhatsAppChannelRecord>,
    val campaigns: List<SocialBoostCampaignRecord>,
    val tasks: List<TaskItemRecord>,
    val appointments: List<AppointmentItemRecord>,
    val aiAgents: List<AiAgentRecord>,
    val integrations: List<IntegrationRecord>,
    val invitations: List<InvitationRecord>,
    val auditLogs: List<AuditLogRecord>
)

object DemoFallbackDataset {
    fun buildSafeDemoSnapshot(
        reason: String,
        diagnostic: ApiDiagnosticInfo = ApiDiagnosticInfo(errorSummary = reason)
    ): CrmWorkspaceSnapshot {
        val tenant = TenantWorkspace(
            id = 1,
            name = "DEMO WORKSPACE (Sample Data Only)",
            slug = "demo-sandbox",
            industry = "International Recruitment & B2B SaaS (Demo)",
            timezone = "Europe/London",
            plan = "Demo Sandbox",
            emergencyPause = false,
            aiDisclosureEnabled = true,
            retentionDays = 365
        )
        return CrmWorkspaceSnapshot(
            isLiveBackend = false,
            connectionBanner = "SAFE DEMO MODE ACTIVE — $reason",
            apiDiagnostic = diagnostic,
            user = UserProfile(
                id = 1,
                uid = "demo-owner-uid-01",
                email = "alammustak355@gmail.com",
                name = "Workspace Owner (Demo Mode)",
                role = "company_owner"
            ),
            activeTenant = tenant,
            authorizedTenants = listOf(tenant),
            contacts = listOf(
                ContactRecord(
                    id = 101,
                    name = "[DEMO] Elena Rostova",
                    phone = "+44 7700 900511",
                    email = "elena.rostova@example.com",
                    company = "[DEMO] EU Healthcare Placement",
                    sourceChannel = "whatsapp",
                    consentStatus = "opted_in",
                    assignedEmployee = "Demo Owner",
                    requirementsSummary = "[DEMO SAMPLE] Registered Nurse (ICU), IELTS 7.5, seeking UK NHS or UAE hospital sponsorship.",
                    notes = "[DEMO RECORD — NOT REAL DATA] Sample nursing candidate record."
                ),
                ContactRecord(
                    id = 102,
                    name = "[DEMO] Henrik Lindqvist",
                    phone = "+46 70 123 4567",
                    email = "h.lindqvist@example.com",
                    company = "[DEMO] Nordic Freight AB",
                    sourceChannel = "instagram",
                    consentStatus = "opted_in",
                    assignedEmployee = "Demo Staff",
                    requirementsSummary = "[DEMO SAMPLE] Seeking 15 HGV Class 1 drivers for Sweden-Germany corridor.",
                    notes = "[DEMO RECORD — NOT REAL DATA] Sample employer inquiry."
                )
            ),
            leads = listOf(
                LeadCandidateRecord(
                    id = 201,
                    title = "[DEMO] Elena Rostova — UK Senior ICU Nurse",
                    contactName = "[DEMO] Elena Rostova",
                    phone = "+44 7700 900511",
                    email = "elena.rostova@example.com",
                    nationality = "Poland (Demo)",
                    preferredJob = "Senior ICU Registered Nurse (Demo)",
                    destinationCountry = "United Kingdom",
                    ownerName = "Demo Owner",
                    sourceChannel = "whatsapp",
                    priority = "urgent",
                    stage = "Qualified",
                    leadScore = 92,
                    extractedRequirements = "[DEMO SAMPLE] IELTS 7.5, 6 yrs ICU experience, NMC CBT passed.",
                    notes = "[DEMO SAMPLE] Not a real candidate record.",
                    estimatedValueUsd = 6500.0,
                    nextAction = "[DEMO] Sample interview follow-up",
                    dueDate = "2026-10-22"
                ),
                LeadCandidateRecord(
                    id = 202,
                    title = "[DEMO] Mateo Silva — Civil Site Engineer (UAE)",
                    contactName = "[DEMO] Mateo Silva",
                    phone = "+351 912 345 678",
                    email = "mateo.silva@example.com",
                    nationality = "Portugal (Demo)",
                    preferredJob = "Civil Site Engineer (Demo)",
                    destinationCountry = "United Arab Emirates",
                    ownerName = "Demo Staff",
                    sourceChannel = "facebook",
                    priority = "high",
                    stage = "Documents Pending",
                    leadScore = 81,
                    extractedRequirements = "[DEMO SAMPLE] 8 years infrastructure & metro experience.",
                    notes = "[DEMO SAMPLE] Not a real candidate record.",
                    estimatedValueUsd = 8200.0,
                    nextAction = "[DEMO] Collect sample engineering diploma",
                    dueDate = "2026-10-24"
                ),
                LeadCandidateRecord(
                    id = 203,
                    title = "[DEMO] Amina Al-Mansoor — Visa Process Completed",
                    contactName = "[DEMO] Amina Al-Mansoor",
                    phone = "+971 50 998 1122",
                    email = "amina@example.com",
                    nationality = "Morocco (Demo)",
                    preferredJob = "Hospitality Operations Manager (Demo)",
                    destinationCountry = "Germany",
                    ownerName = "Demo Owner",
                    sourceChannel = "tiktok",
                    priority = "high",
                    stage = "Deployed",
                    leadScore = 96,
                    extractedRequirements = "[DEMO SAMPLE] Trilingual (Arabic, French, English), 5-star hotel background.",
                    notes = "[DEMO SAMPLE] Not a real candidate record.",
                    estimatedValueUsd = 9400.0,
                    nextAction = "[DEMO] Sample 30-day check-in",
                    dueDate = "2026-11-01"
                )
            ),
            conversations = listOf(
                ConversationRecord(
                    id = 301,
                    customerName = "[DEMO] Elena Rostova",
                    customerHandleOrPhone = "+44 7700 900511",
                    channelType = "whatsapp",
                    status = "open",
                    priority = "high",
                    assignedEmployee = "Demo Owner",
                    handlingMode = "ai_auto",
                    unreadCount = 1,
                    lastMessagePreview = "[DEMO SAMPLE] Hello! I have uploaded my sample NMC CBT certificate.",
                    aiSummary = "[DEMO SAMPLE] Sample candidate confirmed NMC CBT completion.",
                    suggestedReply = "[DEMO DRAFT] Thank you! Would Thursday at 14:00 UTC work for your sample interview?"
                )
            ),
            messages = listOf(
                MessageRecord(
                    id = 401,
                    conversationId = 301,
                    senderType = "customer",
                    senderName = "[DEMO] Elena Rostova",
                    direction = "inbound",
                    content = "[DEMO SAMPLE MESSAGE] Hello! I have uploaded my sample NMC CBT certificate and passport copy. When is the hospital interview?",
                    deliveryStatus = "read"
                )
            ),
            channels = listOf(
                WhatsAppChannelRecord(
                    id = 501,
                    phoneNumber = "+44 20 7946 0192 (Demo)",
                    displayName = "[DEMO] UK Recruitment Desk (Sample Line)",
                    phoneNumberId = "DEMO_WABA_UK_01",
                    channelType = "whatsapp",
                    department = "International Recruitment (Demo)",
                    assignedStaffName = "Demo Owner",
                    aiStatus = "auto_active",
                    connectionStatus = "webhook_ready",
                    recentError = "DEMO MODE: Live backend not connected; showing sample channel."
                )
            ),
            campaigns = listOf(
                SocialBoostCampaignRecord(
                    id = 601,
                    channelType = "instagram",
                    campaignName = "[DEMO] EU & UK Healthcare Nurses Sample Campaign",
                    objective = "Click-to-WhatsApp Candidate Intake (Demo)",
                    adCopy = "[DEMO SAMPLE AD] Registered Nurses: Fast-track UK & EU hospital sponsorship.",
                    dailyBudgetUsd = "65",
                    durationDays = 14,
                    status = "demo_sample",
                    impressions = 18420,
                    clicks = 940,
                    conversationsStarted = 142,
                    qualifiedLeadsCount = 38
                )
            ),
            tasks = listOf(
                TaskItemRecord(
                    id = 701,
                    title = "[DEMO] Verify sample NMC CBT & Passport Copy",
                    taskType = "document_check",
                    assignedEmployee = "Demo Owner",
                    contactName = "[DEMO] Elena Rostova",
                    dueDate = "2026-10-18",
                    priority = "urgent",
                    status = "pending"
                ),
                TaskItemRecord(
                    id = 702,
                    title = "[DEMO] Send sample shortlist to Nordic Freight AB",
                    taskType = "follow_up",
                    assignedEmployee = "Demo Staff",
                    contactName = "[DEMO] Henrik Lindqvist",
                    dueDate = "2026-10-25",
                    priority = "high",
                    status = "pending"
                )
            ),
            appointments = listOf(
                AppointmentItemRecord(
                    id = 801,
                    contactName = "[DEMO] Elena Rostova",
                    title = "[DEMO] Sample UK NHS Trust Clinical Panel Interview",
                    scheduledAt = "2026-10-23 14:00 UTC",
                    durationMinutes = 45,
                    status = "demo_sample",
                    channelSource = "whatsapp"
                )
            ),
            aiAgents = listOf(
                AiAgentRecord(
                    id = 901,
                    name = "[DEMO] Aria Recruitment & Sales Concierge",
                    department = "Recruitment & B2B Intake (Demo)",
                    assignedChannels = "WhatsApp, Instagram, Facebook, TikTok",
                    communicationStyle = "Executive, Warm & Grounded",
                    confidenceThreshold = 82,
                    responseMode = "auto",
                    isActive = true
                )
            ),
            integrations = listOf(
                IntegrationRecord(
                    id = 1001,
                    providerKey = "meta_whatsapp_cloud",
                    displayName = "Meta WhatsApp Business Cloud API",
                    category = "messaging",
                    status = "not_connected_demo",
                    maskedCredentialHint = "META_WHATSAPP_ACCESS_TOKEN required on deployed backend",
                    requiredPermissions = "whatsapp_business_messaging, whatsapp_business_management",
                    setupInstructions = "Deploy backend to public Cloud Run and configure META_WHATSAPP_ACCESS_TOKEN."
                ),
                IntegrationRecord(
                    id = 1002,
                    providerKey = "google_gemini_ai",
                    displayName = "Google Gemini AI (Server-Side Grounded Copilot)",
                    category = "ai",
                    status = "requires_live_backend",
                    maskedCredentialHint = "Server-Side GEMINI_API_KEY",
                    requiredPermissions = "Server-side proxy only (Zero client key exposure)",
                    setupInstructions = "Deploy Express backend to public Cloud Run to enable live /api/ai/copilot calls."
                )
            ),
            invitations = listOf(
                InvitationRecord(
                    id = 1101,
                    email = "demo.staff@example.com",
                    role = "manager",
                    department = "Recruitment Operations (Demo)",
                    status = "demo_sample",
                    invitedBy = "Demo Owner"
                )
            ),
            auditLogs = listOf(
                AuditLogRecord(
                    id = 1201,
                    actorName = "Android Client Diagnostics",
                    action = "LIVE_API_UNREACHABLE_FALLBACK",
                    resourceType = "network",
                    details = "Fallback to labeled Demo Mode: $reason"
                )
            )
        )
    }
}
